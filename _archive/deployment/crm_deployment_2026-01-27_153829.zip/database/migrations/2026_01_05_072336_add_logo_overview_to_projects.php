<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('projects', function (Blueprint $table) {
            $table->string('logo')->nullable()->after('name');
            $table->text('short_overview')->nullable()->after('logo');
            $table->enum('residential_sub_type', ['plot', 'flat', 'villa'])->nullable()->after('project_type');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('projects', function (Blueprint $table) {
            $table->dropColumn(['logo', 'short_overview', 'residential_sub_type']);
        });
    }
};
