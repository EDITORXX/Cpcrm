<?php

namespace App\Http\Controllers;

use App\Models\GoogleSheetsConfig;
use App\Models\GoogleSheetsColumnMapping;
use App\Models\SmartImportAutomation;
use App\Models\ImportBatch;
use App\Models\ImportedLead;
use App\Services\LeadImportService;
use App\Services\GoogleSheetsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class LeadImportController extends Controller
{
    protected $importService;
    protected $sheetsService;

    public function __construct(
        LeadImportService $importService,
        GoogleSheetsService $sheetsService
    ) {
        $this->importService = $importService;
        $this->sheetsService = $sheetsService;
    }
    
    /**
     * Convert index to column letter (0=A, 1=B, ..., 25=Z, 26=AA, 27=AB, etc.)
     */
    private static function indexToColumnLetter(int $index): string
    {
        $result = '';
        $index++; // Convert to 1-based
        
        while ($index > 0) {
            $index--;
            $result = chr(65 + ($index % 26)) . $result;
            $index = intval($index / 26);
        }
        
        return $result;
    }

    /**
     * Lead Import Dashboard
     */
    public function index()
    {
        $configs = GoogleSheetsConfig::where('created_by', auth()->id())
            ->where('is_active', true)
            ->latest()
            ->get();

        $recentImports = ImportBatch::where('user_id', auth()->id())
            ->latest()
            ->limit(10)
            ->get();

        // Get last 5 imported leads with actual assignments
        $recentImportedLeads = ImportedLead::whereHas('importBatch', function($query) {
                $query->where('user_id', auth()->id());
            })
            ->with([
                'lead.activeAssignments.assignedTo', // Load actual assignments
                'assignedTo', // Load ImportedLead.assigned_to
                'importBatch'
            ])
            ->latest()
            ->limit(5)
            ->get();

        $stats = [
            'total_imports' => ImportBatch::where('user_id', auth()->id())->count(),
            'total_leads_imported' => ImportBatch::where('user_id', auth()->id())->sum('imported_leads'),
            'pending_imports' => ImportBatch::where('user_id', auth()->id())
                ->whereIn('status', ['pending', 'processing'])->count(),
            'failed_imports' => ImportBatch::where('user_id', auth()->id())
                ->where('status', 'failed')->count(),
        ];

        return view('lead-import.index', compact('configs', 'recentImports', 'recentImportedLeads', 'stats'));
    }

    /**
     * Get Google Sheets Config
     */
    public function getGoogleSheetsConfig(Request $request)
    {
        $configId = $request->get('config_id');

        if ($configId) {
            $config = GoogleSheetsConfig::with('columnMappings')
                ->where('id', $configId)
                ->where('created_by', auth()->id())
                ->firstOrFail();

            // Remove sensitive data
            $configData = $config->toArray();
            unset($configData['api_key'], $configData['refresh_token'], $configData['service_account_json_path']);
            
            // Add column mappings
            $configData['column_mappings'] = $config->columnMappings->map(function($mapping) {
                return [
                    'id' => $mapping->id,
                    'sheet_column' => $mapping->sheet_column,
                    'lead_field_key' => $mapping->lead_field_key,
                    'field_type' => $mapping->field_type,
                    'field_label' => $mapping->field_label,
                    'is_required' => $mapping->is_required,
                ];
            })->toArray();

            return response()->json([
                'success' => true,
                'config' => $configData,
            ]);
        }

        // Return all active configs
        $configs = GoogleSheetsConfig::where('created_by', auth()->id())
            ->where('is_active', true)
            ->get()
            ->map(function ($config) {
                $data = $config->toArray();
                unset($data['api_key'], $data['refresh_token'], $data['service_account_json_path']);
                return $data;
            });

        return response()->json([
            'success' => true,
            'configs' => $configs,
        ]);
    }

    /**
     * Save Google Sheets Config
     */
    public function saveGoogleSheetsConfig(Request $request)
    {
        $request->validate([
            'config_id' => 'nullable|exists:google_sheets_config,id',
            'sheet_id' => 'required|string',
            'sheet_name' => 'required|string|max:255',
            'api_key' => 'nullable|string|max:255',
            'service_account_json_path' => 'nullable|string|max:500',
            'range' => 'required|string|max:50',
            'name_column' => 'required|string|size:1|regex:/^[A-Z]$/',
            'phone_column' => 'required|string|size:1|regex:/^[A-Z]$/',
            'auto_sync_enabled' => 'boolean',
            'sync_interval_minutes' => 'required|integer|min:1',
            'automation_id' => 'nullable|exists:smart_import_automations,id',
            'custom_columns_json' => 'nullable|string',
        ]);

        try {
            // Extract sheet ID from URL if needed
            $sheetId = GoogleSheetsConfig::extractSheetId($request->sheet_id);
            if (!$sheetId) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid sheet ID format. Please provide a valid Google Sheet ID or URL.',
                ], 400);
            }

            $data = $request->only([
                'sheet_name',
                'api_key',
                'service_account_json_path',
                'range',
                'name_column',
                'phone_column',
                'auto_sync_enabled',
                'sync_interval_minutes',
                'automation_id',
            ]);

            // Apply defaults if not provided
            $data['auto_sync_enabled'] = $request->boolean('auto_sync_enabled', true);
            $data['sync_interval_minutes'] = $data['sync_interval_minutes'] ?? 2;

            $data['sheet_id'] = $sheetId;
            $data['created_by'] = auth()->id();

            DB::beginTransaction();
            try {
                if ($request->config_id) {
                    $config = GoogleSheetsConfig::where('id', $request->config_id)
                        ->where('created_by', auth()->id())
                        ->firstOrFail();
                    $config->update($data);
                } else {
                    $config = GoogleSheetsConfig::create($data);
                }
                
                // Handle custom column mappings
                if ($request->has('custom_columns_json') && $request->custom_columns_json) {
                    $customColumns = json_decode($request->custom_columns_json, true);
                    
                    if (is_array($customColumns)) {
                        // Get existing mapping IDs to keep
                        $existingIds = collect($customColumns)->pluck('id')->filter()->toArray();
                        
                        // Delete mappings that are not in the new list
                        GoogleSheetsColumnMapping::where('google_sheets_config_id', $config->id)
                            ->whereNotIn('id', $existingIds)
                            ->delete();
                        
                        // Create or update mappings
                        foreach ($customColumns as $index => $columnData) {
                            if (empty($columnData['sheet_column']) || empty($columnData['lead_field_key']) || empty($columnData['field_label'])) {
                                continue;
                            }
                            
                            $mappingData = [
                                'google_sheets_config_id' => $config->id,
                                'sheet_column' => strtoupper($columnData['sheet_column']),
                                'lead_field_key' => $columnData['lead_field_key'],
                                'field_type' => $columnData['field_type'] ?? 'custom',
                                'field_label' => $columnData['field_label'],
                                'is_required' => $columnData['is_required'] ?? false,
                                'display_order' => $index,
                            ];
                            
                            if (!empty($columnData['id'])) {
                                GoogleSheetsColumnMapping::where('id', $columnData['id'])
                                    ->where('google_sheets_config_id', $config->id)
                                    ->update($mappingData);
                            } else {
                                GoogleSheetsColumnMapping::create($mappingData);
                            }
                        }
                    }
                } else {
                    // If no custom columns JSON provided, delete all existing custom mappings
                    GoogleSheetsColumnMapping::where('google_sheets_config_id', $config->id)->delete();
                }
                
                DB::commit();
            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

            // Reload config with relationships
            $config->load('columnMappings');
            
            // Remove sensitive data from response
            $configData = $config->toArray();
            unset($configData['api_key'], $configData['refresh_token'], $configData['service_account_json_path']);
            
            // Add column mappings to response
            $configData['column_mappings'] = $config->columnMappings->map(function($mapping) {
                return [
                    'id' => $mapping->id,
                    'sheet_column' => $mapping->sheet_column,
                    'lead_field_key' => $mapping->lead_field_key,
                    'field_type' => $mapping->field_type,
                    'field_label' => $mapping->field_label,
                    'is_required' => $mapping->is_required,
                ];
            })->toArray();

            return response()->json([
                'success' => true,
                'config' => $configData,
                'message' => $request->config_id ? 'Configuration updated successfully.' : 'Configuration created successfully.',
            ]);

        } catch (\Exception $e) {
            Log::error("Error saving Google Sheets config: " . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to save configuration: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get All Google Sheets Configs
     */
    public function getAllGoogleSheetsConfigs()
    {
        $configs = GoogleSheetsConfig::where('created_by', auth()->id())
            ->where('is_active', true)
            ->with(['assignmentRule', 'creator'])
            ->latest()
            ->get()
            ->map(function ($config) {
                $data = $config->toArray();
                unset($data['api_key'], $data['refresh_token'], $data['service_account_json_path']);
                return $data;
            });

        return response()->json([
            'success' => true,
            'configs' => $configs,
        ]);
    }

    /**
     * Delete Google Sheets Config
     */
    public function deleteGoogleSheetsConfig($id)
    {
        try {
            $config = GoogleSheetsConfig::where('id', $id)
                ->where('created_by', auth()->id())
                ->firstOrFail();

            // Soft delete
            $config->update(['is_active' => false]);

            return response()->json([
                'success' => true,
                'message' => 'Configuration deleted successfully.',
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete configuration.',
            ], 500);
        }
    }

    /**
     * Fetch Sheet Headers (First Row)
     */
    public function fetchSheetHeaders(Request $request)
    {
        $request->validate([
            'sheet_id' => 'required|string',
            'sheet_name' => 'required|string|max:255',
            'api_key' => 'nullable|string|max:255',
            'service_account_json_path' => 'nullable|string|max:500',
        ]);

        try {
            // Extract sheet ID from URL if needed
            $sheetId = GoogleSheetsConfig::extractSheetId($request->sheet_id);
            if (!$sheetId) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid sheet ID format. Please provide a valid Google Sheet ID or URL.',
                ], 400);
            }

            // Fetch only row 1 (headers)
            $headers = $this->sheetsService->fetchSheetData(
                $sheetId,
                $request->sheet_name,
                'A:Z', // Default range
                $request->api_key,
                $request->service_account_json_path,
                1 // Start from row 1
            );

            if (empty($headers) || !isset($headers[0])) {
                return response()->json([
                    'success' => false,
                    'message' => 'No headers found in the sheet. Please check the sheet name and ensure row 1 contains column headers.',
                ], 404);
            }

            // Get first row as headers
            $headerRow = $headers[0];
            
            // Convert to column format with positions
            $columns = [];
            
            foreach ($headerRow as $index => $headerText) {
                // Convert index to column letter (A=0, B=1, ..., Z=25, AA=26, AB=27, etc.)
                $columnLetter = self::indexToColumnLetter($index);
                
                $columns[] = [
                    'position' => $columnLetter,
                    'header' => trim($headerText ?? ''),
                    'index' => $index,
                ];
            }

            return response()->json([
                'success' => true,
                'columns' => $columns,
            ]);

        } catch (\Exception $e) {
            Log::error("Error fetching sheet headers: " . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch headers: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Sync Google Sheets
     */
    public function syncGoogleSheets(Request $request)
    {
        $request->validate([
            'config_id' => 'required|exists:google_sheets_config,id',
        ]);

        try {
            $config = GoogleSheetsConfig::where('id', $request->config_id)
                ->where('created_by', auth()->id())
                ->where('is_active', true)
                ->firstOrFail();

            $result = $this->sheetsService->syncGoogleSheets($config);

            return response()->json([
                'success' => true,
                'imported' => $result['imported'],
                'skipped' => $result['skipped'],
                'total_rows' => $result['imported'] + $result['skipped'],
                'errors' => $result['errors'],
                'is_complete' => empty($result['errors']),
                'last_synced_row' => $result['last_synced_row'],
                'message' => "Successfully imported {$result['imported']} leads. {$result['skipped']} skipped.",
            ]);

        } catch (\Exception $e) {
            Log::error("Google Sheets sync error: " . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Sync failed: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Show CSV Import Form
     */
    public function showCsvForm()
    {
        $automations = SmartImportAutomation::where('created_by', auth()->id())
            ->where('status', 'active')
            ->latest()
            ->get();

        return view('lead-import.csv', compact('automations'));
    }

    /**
     * Import CSV
     */
    public function importCsv(Request $request)
    {
        $request->validate([
            'csv_file' => 'required|file|mimes:csv,txt|max:10240',
            'automation_id' => 'required|exists:smart_import_automations,id',
        ]);

        try {
            $file = $request->file('csv_file');
            
            // Parse CSV
            $leads = $this->importService->parseCsvFile($file);

            if (empty($leads)) {
                return back()->withErrors(['csv_file' => 'No valid leads found in CSV file.']);
            }

            // Store file
            $fileName = 'imports/' . time() . '_' . $file->getClientOriginalName();
            Storage::putFileAs('public', $file, $fileName);

            // Get automation
            $automation = SmartImportAutomation::findOrFail($request->automation_id);
            
            // Import leads using automation config
            $batch = $this->importService->importFromCsvWithAutomation(
                $leads,
                $request->user()->id,
                $automation
            );

            // Update batch with file name
            $batch->update(['file_name' => $fileName]);

            return redirect()
                ->route('lead-import.index')
                ->with('success', "Successfully imported {$batch->imported_leads} leads. {$batch->failed_leads} failed.");

        } catch (\Exception $e) {
            return back()->withErrors(['csv_file' => $e->getMessage()]);
        }
    }

    /**
     * Preview CSV
     */
    public function previewCsv(Request $request)
    {
        $request->validate([
            'csv_file' => 'required|file|mimes:csv,txt|max:10240',
        ]);

        try {
            $file = $request->file('csv_file');
            $leads = $this->importService->parseCsvFile($file);

            return response()->json([
                'success' => true,
                'total' => count($leads),
                'preview' => array_slice($leads, 0, 10), // First 10 rows
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Import History
     */
    public function history()
    {
        $imports = ImportBatch::where('user_id', auth()->id())
            ->with(['assignmentRule', 'user'])
            ->latest()
            ->paginate(20);

        return view('lead-import.history', compact('imports'));
    }
}
